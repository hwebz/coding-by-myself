import React, { PropTypes } from 'react';

const Switch = React.createClass({
  getInitialState() {
    return {}; // The initial state
  },

  render() {
    return <div><em>Template will be here</em></div>;
  }
});

module.exports = Switch;
