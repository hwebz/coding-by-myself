This project contains a Node API server and a React app generated with create-react-app under `client/`.

We complete the setup for this app in the chapter "Using Webpack with create-react-app".