# vue-standupnotes-client
The (mostly) complete client project for the Pluralsight course Fundamentals of Mongoose for Node and MongoDB

Note: be sure to run 'yarn' or 'npm install' 
