import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-differs-demo',
  templateUrl: './differs-demo.component.html',
  styles: []
})
export class DiffersDemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
